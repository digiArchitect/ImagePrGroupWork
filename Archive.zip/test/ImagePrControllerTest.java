/**
 * Tests the processor's controller
 */
public class ImagePrControllerTest {

  public void setup() {

  }

  public void testConstructor() {

  }

  public void testConstructorFails() {

  }

  public void testWelcome() {

  }

  public void testQuitRandomChars() {

  }

  public void testQuitRandomNums() {

  }

  public void testInvalidMock() {

  }

  public void testValidMock() {

  }

  public void testResults() {

  }
}
